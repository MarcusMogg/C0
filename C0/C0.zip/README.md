﻿实现基础c0部分+注释+字符串字面量+char类型转换

## 编译项目

linux下

```
chmod +x build.sh
./build.sh
```

## 运行项目

```
chmod +x cc0
./cc0
```